import os
import numpy as np
import tensorflow as tf
import tensorflow_hub as hub
# import librosa
from flask import Flask, request, jsonify, render_template
import scipy
from scipy.io import wavfile
import csv
import matplotlib.pyplot as plt
from IPython.display import Audio
from tensorflow.keras.models import load_model

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Load YAMNet model from TF Hub
yamnet_model = hub.load('https://tfhub.dev/google/yamnet/1')

# Load custom classifier
classifier_model = tf.keras.models.load_model("my_yamnet_human_model.keras")

# Find the name of the class with the top score when mean-aggregated across frames.
def class_names_from_csv(class_map_csv_text):
    """Returns list of class names corresponding to score vector."""
    class_names = []
    with tf.io.gfile.GFile(class_map_csv_text) as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            class_names.append(row['display_name'])

    return class_names

class_names = ['Baby cry, infant cry', 'Breathing', 'Brushing teeth', 'Clapping', 'Cough', 'Laughter','Pouring water','Sneeze','Snoring','Walk, footsteps']

def ensure_sample_rate(original_sample_rate, waveform, desired_sample_rate=16000):
    """Resample waveform if required."""
    if original_sample_rate != desired_sample_rate:
        desired_length = int(round(float(len(waveform)) /
                                    original_sample_rate * desired_sample_rate))
        waveform = scipy.signal.resample(waveform, desired_length)
    return desired_sample_rate, waveform

def predict_audio(file_path):
    sample_rate, wav_data = wavfile.read(file_path, 'rb')
    sample_rate, wav_data = ensure_sample_rate(sample_rate, wav_data)
    waveform = wav_data / tf.int16.max

    # Step 1: Get YAMNet output (scores, embeddings, spectrogram)
    scores, embeddings, spectrogram = yamnet_model(waveform)

    # Step 2: Average the embeddings across time
    mean_embedding = tf.reduce_mean(embeddings, axis=0)  # shape (1024,)

    # Step 3: Run your classifier on the embedding
    mean_embedding = tf.expand_dims(mean_embedding, axis=0)  # shape (1, 1024)
    prediction = classifier_model.predict(mean_embedding)
    predicted_index = np.argmax(prediction)
    predicted_label = class_names[predicted_index]

    print(f"Predicted: {predicted_label}")
    return predicted_label

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'})

    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'})

    file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(file_path)

    result = predict_audio(file_path)
    return jsonify({'prediction': result})


if __name__ == '__main__':
    app.run(debug=True)
